import requests
from bs4 import BeautifulSoup
import re
import sys
import time

# File to store all results
filename = 'Exam_Associate_Cloud_Engineer_Results.txt'

# Headers to mimic a browser request
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

# Open the file for writing results
with open(filename, 'w') as file:
    for question_number in range(1, 284):  # Loop from 1 to 283
        search_topic = f"Exam Associate Cloud Engineer question {question_number}"
        search_url = f"https://www.google.com/search?q={search_topic.replace(' ', '+')}"
        
        attempt = 0
        max_attempts = 3
        first_url = None
        
        while attempt < max_attempts:
            try:
                # Send the request
                response = requests.get(search_url, headers=headers)
                response.raise_for_status()
                
                # Parse the HTML content
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Find the first search result URL
                result = soup.find('div', class_='tF2Cxc')
                first_url = result.find('a')['href'] if result else None

                if first_url:
                    print(f"Question {question_number}: {first_url}")
                    file.write(f"Question {question_number}: {first_url}\n")
                    break  # Exit retry loop if URL is found
                else:
                    print(f"Attempt {attempt + 1}: No valid URL found for question {question_number}. Retrying...")
                    time.sleep(1)  # Wait 1 second before retrying
            except requests.exceptions.RequestException as e:
                print(f"Attempt {attempt + 1}: An error occurred for question {question_number}: {e}")
            
            attempt += 1

        # If no URL was found after max attempts, log failure
        if not first_url:
            print(f"Question {question_number}: No valid URL found after {max_attempts} attempts.")
            file.write(f"Question {question_number}: No valid URL found after {max_attempts} attempts.\n")
        
        # Wait 1 second between searches to avoid rate-limiting
        time.sleep(1)

print("\nSearch completed. All results saved in:", filename)
