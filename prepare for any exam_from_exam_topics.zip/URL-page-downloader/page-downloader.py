import os
import requests
from bs4 import BeautifulSoup
import time

# Set the download path
download_path = r'C:\Users\ahabdelkhalek\Downloads\tetris\ExamTopicsQuizMaker\res'

# Ensure the directory exists
if not os.path.exists(download_path):
    os.makedirs(download_path)

# Function to clean the file name
def clean_filename(title):
    invalid_chars = '<>:"/\|?*'
    for char in invalid_chars:
        title = title.replace(char, '_')
    return title.strip()

# Function to download and save the webpage
def download_webpage(url, folder):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        # Parse the HTML content to extract the title
        soup = BeautifulSoup(response.content, 'html.parser')
        title_tag = soup.find('title')
        if title_tag:
            title = title_tag.text
            filename = clean_filename(title) + '.html'
            # Check if the file already exists
            if os.path.exists(os.path.join(folder, filename)):
                i = 1
                while os.path.exists(os.path.join(folder, f"{filename[:-5]}_{i}.html")):
                    i += 1
                filename = f"{filename[:-5]}_{i}.html"
            # Save the webpage content
            with open(os.path.join(folder, filename), 'wb') as f:
                f.write(response.content)
            print(f"Downloaded: {filename}")
        else:
            print(f"No title found for URL: {url}")
    except requests.exceptions.RequestException as e:
        print(f"Error downloading {url}: {e}")

# Read the list of URLs from the file
with open('Exam_Associate_Cloud_Engineer_Results.txt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Extract URLs from lines
urls = [line.split(': ')[1].strip() for line in lines if line.startswith('Question')]

# Download each webpage with a delay
for url in urls:
    download_webpage(url, download_path)
    time.sleep(5)  # Delay in seconds to avoid getting blocked

print("Download complete.")